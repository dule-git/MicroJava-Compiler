package rs.ac.bg.etf.pp1;

import rs.ac.bg.etf.pp1.ast.VisitorAdaptor;
import rs.ac.bg.etf.pp1.CounterVisitor.VarCounter;
import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.mj.runtime.Code;
import rs.etf.pp1.symboltable.*;
import rs.etf.pp1.symboltable.concepts.*;

public class CodeGenerator extends VisitorAdaptor
{
	private int mainPC;
	int adr;
	int adr2;
	
	public int getMainPC() { return this.mainPC; }
	
	public void visit(MethodTypeName meth) 
	{
		this.mainPC = Code.pc;
		meth.obj.setAdr(Code.pc);
		
		SyntaxNode methNode = meth.getParent();
		VarCounter varCounter = new VarCounter();
		methNode.traverseTopDown(varCounter);
		
		Code.put(Code.enter);
		Code.put(0); // num of formal parameters
		Code.put(0 + varCounter.getCount()); // num of formal parameters + local variables
	}
	
	public void visit(Method meth) 
	{
		Code.put(Code.exit);
		Code.put(Code.return_);
	}
	
	public void visit(ReadStatement stmt)
	{
		Obj dObj = stmt.getDesignator().obj;
		
		if (dObj.getType().getKind() == Struct.Array){
			if (dObj.getType().getElemType().equals(Tab.charType)) {
				Code.put(Code.bread);
				Code.put(Code.bastore);
			}
			else {
				Code.put(Code.read);
				Code.put(Code.astore);
			}
		} else {
			if (dObj.getType().equals(Tab.charType)) 
				Code.put(Code.bread);
			else
				Code.put(Code.read);
			Code.store(dObj);
		}
	}
	
	public void visit(PrintStatement stmt)
	{
		int intWidth = 5;
		int charWidth = 1;
		Expr e = stmt.getExpr();
		NumConstOpt numConst = stmt.getNumConstOpt();
		
		if (numConst instanceof NumberConst)
			intWidth = charWidth = ((NumberConst)numConst).getValue().intValue();
		
		if (e.struct.equals(Tab.intType)) {
			Code.loadConst(intWidth);
			Code.put(Code.print);
		} else if (e.struct.equals(Tab.charType)) {
			Code.loadConst(charWidth);
			Code.put(Code.bprint);
		} else {
			Code.loadConst(charWidth);
			Code.put(Code.print);
		}	
		
		// printing new line
		Code.loadConst(10);
		Code.loadConst(1);
		Code.put(Code.bprint);
		Code.loadConst(13);
		Code.loadConst(1);
		Code.put(Code.bprint);
	}
	
	public void visit(Condition con)
	{
		Code.loadConst(1);
		Code.putFalseJump(Code.eq, 0);
		this.adr = Code.pc - 2;
	}
	
	public void visit(FirstExpr first)
	{
		Code.putJump(0);
		this.adr2 = Code.pc - 2;
		Code.fixup(this.adr);
	}
	
	public void visit(SecondExpr second)
	{
		Code.fixup(this.adr2);
	}
	
	public void visit(AssignOperation assign) 
	{
		DesignatorStatement ds = (DesignatorStatement) assign.getParent();
		Obj dObj = ds.getDesignator().obj;
		
		// if array
		if (dObj.getType().getKind() == Struct.Array) {
			// if assigning to an array element
			if (ds.getDesignator().getDesignatorExtention() instanceof ArrayField)
				if (dObj.getType().getElemType().equals(Tab.charType))
					Code.put(Code.bastore);
				else
					Code.put(Code.astore);
			// else assigning to an array with a "new" statement
			else
				Code.store(dObj);
		} else if (dObj.getType().getKind() != Struct.Array) 
			Code.store(dObj);
	}
	
	
	public void visit(AddopExpression exp)
	{
		Addop addop = exp.getAddop();
		if (addop instanceof Plus)
			Code.put(Code.add);
		else
			Code.put(Code.sub);
	}
	
	public void visit(TermExpression term)
	{
		if (term.getMinusOpt() instanceof MinusSign)
			Code.put(Code.neg);
	}
	
	public void visit(MulopTerm term)
	{
		Mulop mulop = term.getMulop();
		if (mulop instanceof Times)
			Code.put(Code.mul);
		else if (mulop instanceof DividedBy)
			Code.put(Code.div);
		else if (mulop instanceof Mod)
			Code.put(Code.rem);
	}
	
	public void visit(Increment inc)
	{
		Obj dObj  = ((DesignatorStatement)inc.getParent()).getDesignator().obj;
		
		if (dObj.getType().getKind() == Struct.Array) {
			Code.put(Code.dup2);
			Code.put(Code.aload);
			Code.loadConst(1);
			Code.put(Code.add);
			Code.put(Code.astore);			
		} else {
			Code.loadConst(1);
			Code.put(Code.add);
			Code.store(dObj);
		}
	}
	
	public void visit(Decrement dec)
	{
		Obj dObj  = ((DesignatorStatement)dec.getParent()).getDesignator().obj;
		
		if (dObj.getType().getKind() == Struct.Array) {
			Code.put(Code.dup2);
			Code.put(Code.aload);
			Code.loadConst(1);
			Code.put(Code.sub);
			Code.put(Code.astore);			
		} else {
			Code.loadConst(1);
			Code.put(Code.sub);
			Code.store(dObj);
		}
	}
	
	public void visit(DesignatorName dname)
	{
		Designator d = (Designator)dname.getParent();
		
		if (d.obj.getType().getKind() == Struct.Array) {
			// if its not a "new" statement
			if (d.getDesignatorExtention() instanceof ArrayField)
				if (d.getParent() instanceof DesigFactor)
					Code.load(d.obj);
				else if (d.getParent() instanceof DesignatorStatement)
					Code.load(d.obj);
				else if (d.getParent() instanceof ReadStatement)
					Code.load(d.obj);
		} else if (d.getParent() instanceof DesignatorStatement) {
			if (!(((DesignatorStatement)d.getParent()).getDesignatorStatementExtention() instanceof AssignOperation)) 
				Code.load(d.obj);
		}
		else if (!(d.getParent() instanceof ReadStatement) && !(d.getParent() instanceof DesignatorStatement)) {
			Code.load(d.obj);
		}
	}
	
	public void visit(ArrayField af) 
	{
		Designator d = (Designator)af.getParent();
		if (d.getParent() instanceof DesigFactor) 
			if (d.obj.getType().getElemType().equals(Tab.charType))
				Code.put(Code.baload);
			else
				Code.put(Code.aload);
	}
	
	public void visit(AllocFactor af)
	{
		Struct allocType = af.getType().struct;
		int b = 1;
		
		if (allocType.equals(Tab.charType))
			b = 0;
		
		Code.put(Code.newarray);
		Code.put(b);
	}
	
	public void visit(NumConst c) 
	{
		Obj cObj = Tab.insert(Obj.Con, "$", c.struct);
		cObj.setLevel(0);
		cObj.setAdr(c.getNumConst().intValue());
		
		Code.load(cObj);
	}
	
	public void visit(CharConst c) 
	{
		Obj cObj = Tab.insert(Obj.Con, "$", c.struct);
		cObj.setLevel(0);
		int cInt = c.getCharConst().charAt(1);
		cObj.setAdr(cInt);
		
		Code.load(cObj);
	}
	
	public void visit(BoolConst c) 
	{
		Obj cObj = Tab.insert(Obj.Con, "$", c.struct);
		cObj.setLevel(0);
		cObj.setAdr(c.getBoolConst().equals("true") ? 1 : 0);
		
		Code.load(cObj);
	}
}
