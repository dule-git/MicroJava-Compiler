package rs.ac.bg.etf.pp1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;

import java_cup.runtime.Symbol;
import rs.ac.bg.etf.pp1.ast.Program;
import rs.etf.pp1.mj.runtime.Code;
import rs.etf.pp1.symboltable.Tab;
import rs.etf.pp1.symboltable.concepts.Obj;
import rs.etf.pp1.symboltable.concepts.Struct;
import rs.etf.pp1.symboltable.visitors.SymbolTableVisitor;

public class Compiler
{
	public static void main(String[] argv)
	{
		Reader br = null;
		try
		{
			File sourceCode = new File(argv[0]);
			File outputFile = null;
			FileWriter output = null;
			if (argv.length > 1) {
				if (argv[1].equals("out"))
					outputFile = new File(argv[0].replace(".mj", ".out"));
				else 
					outputFile = new File(argv[0].replace(".mj", ".err"));
				output= new FileWriter(outputFile);
			} 
			
			System.out.println("Compiling source file: " + sourceCode.getAbsolutePath());

			br = new BufferedReader(new FileReader(sourceCode));
			Yylex lexer = new Yylex(br);

			MJParser p = new MJParser(lexer);
			Symbol s = p.parse(); // pocetak parsiranja

			Program prog = (Program) (s.value);
			Tab.init();
			Tab.currentScope.addToLocals(new Obj(Obj.Type, "bool", new Struct(Struct.Bool)));
			
			// ispis sintaksnog stabla
			System.out.println(prog.toString(""));
			System.out.println("===================================");
			if (output != null) {
				output.append(prog.toString(""));
				output.append("\n==================================");
			}

			// ispis prepoznatih programskih konstrukcija
			SemanticAnalyzer v = new SemanticAnalyzer();
			prog.traverseBottomUp(v);
			if (output != null) output.append(v.report() + "\n");
			
			System.out.println(v.finalReport());
			if (output != null) output.append(v.finalReport() + "\n\n");
			
			if (p.errorDetected) {
				System.out.println("Error(s) detected during parsing! BUILD FAILED!");
				if (output != null) output.append("Error(s) detected during parsing! BUILD FAILED!");
			} else if (!v.passed()) {
				System.out.println("Error(s) detected during semantic analysis! BUILD FAILED!");
				if (output != null) output.append("Error(s) detected during semantic analysis! BUILD FAILED!");
			} else {
				System.out.println("BUILD SUCCESSFUL!");
				tsdump(output);
				output.close();
				
				File objFile = new File(argv[0].replace(".mj", ".obj"));
				if (objFile.exists()) objFile.delete();
				
				CodeGenerator cd = new CodeGenerator();
				prog.traverseBottomUp(cd);
				
				Code.dataSize = v.nVars;
				Code.mainPc = cd.getMainPC();
				Code.write(new FileOutputStream(objFile));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}finally 
		{
			if (br != null)
				try
				{
					br.close();
				} catch (IOException e1)
				{
					System.out.println(e1.getMessage());
				}
		}
	}
	
	public static void tsdump(FileWriter output) throws IOException
	{
		SymbolTableVisitor stv = new CustomDumpSymbolTableVisitor();
		Tab.dump(stv);
		if (output != null) {
			output.append("BUILD SUCCESSFUL!\n");
			output.append("============================= SYMBOL TABLE DUMP ====================================\n");
			output.append(stv.getOutput());
		}
	}
}
