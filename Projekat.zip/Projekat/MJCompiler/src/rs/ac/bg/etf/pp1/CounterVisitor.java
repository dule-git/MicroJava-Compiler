package rs.ac.bg.etf.pp1;

import rs.ac.bg.etf.pp1.ast.Variable;
import rs.ac.bg.etf.pp1.ast.VariableExtention;
import rs.ac.bg.etf.pp1.ast.VisitorAdaptor;

public class CounterVisitor extends VisitorAdaptor
{
	protected int count = 0;
	
	public int getCount() { return count; }
	
	public static class VarCounter extends CounterVisitor 
	{
		public void visit(Variable var) { this.count++; } 
		public void visit(VariableExtention var) { this.count++; }
	}
}
