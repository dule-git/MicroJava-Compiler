package rs.ac.bg.etf.pp1;

import rs.ac.bg.etf.pp1.ast.*;
import rs.etf.pp1.symboltable.*;
import rs.etf.pp1.symboltable.concepts.*;

public class SemanticAnalyzer extends VisitorAdaptor
{
	Obj currentMethod = null;
	int numOfErrors = 0;
	int nVars;
	private boolean universeScope = true;
	private int numGlobalVars;
	private int numGlobalConstants;
	private int numGlobalArrays;
	private int numMainVars;
	private int numMainStatements;
	private StringBuilder report = new StringBuilder();;
	
	public void report_error(String message, SyntaxNode info) {
		this.numOfErrors++;
		StringBuilder msg = new StringBuilder(message);
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" on line ").append(line);
		System.out.println(msg.toString());
		report.append("\n" + msg.toString());
	}

	public void report_info(String message, SyntaxNode info) {
		StringBuilder msg = new StringBuilder(message); 
		int line = (info == null) ? 0: info.getLine();
		if (line != 0)
			msg.append (" on line ").append(line);
		System.out.println(msg.toString());
		report.append("\n" + msg.toString());
	}
	
	public void visit(ProgramName programName)
	{
		programName.obj = Tab.insert(Obj.Prog, programName.getProgramName(), Tab.noType);
		Tab.openScope();
	}
	
	public void visit(Program program)
	{
		nVars = Tab.currentScope.getnVars();
		Tab.chainLocalSymbols(program.getProgramName().obj);
		Tab.closeScope();
	}
	
	public void visit(Variable variable)
	{
		// if variable exists then output error
		if (Tab.currentScope.findSymbol(variable.getVarName()) != null) {
			report_error("Error on line " + variable.getLine() + ": name " + variable.getVarName() + " already declared!", null);
			return;
		}
		
		// if type is array
		Struct varType;
		if (variable.getBrackets() instanceof YesBrackets) {
			varType = new Struct(Struct.Array, variable.getType().struct);
			if (universeScope)
				this.numGlobalArrays++;
			report_info("Array [" + variable.getVarName() + "] declared", variable);
		}
		else {
			varType = variable.getType().struct;
			if (universeScope)
				this.numGlobalVars++;
			report_info("Variable [" + variable.getVarName() + "] declared", variable);
		}
		
		
		Tab.insert(Obj.Var, variable.getVarName(), varType);
	}
	
	public void visit(VariableExtention variableExtention)
	{
		// if variable exists then output error
		if (Tab.currentScope.findSymbol(variableExtention.getVarName()) != null) {
			report_error("Error on line " + variableExtention.getLine() + ": name " + variableExtention.getVarName() + " already declared!", null);
			return;
		}
		
		// go back to parent to see the type
		SyntaxNode parent = variableExtention.getParent();
		while(!(parent instanceof Variable))
			parent = parent.getParent();
		Variable varParent = (Variable)parent;
		
		// if type is array
		Struct veType = varParent.getType().struct;
		if (variableExtention.getBrackets() instanceof YesBrackets) {
			veType = new Struct(Struct.Array, veType);
			if (universeScope)
				this.numGlobalArrays++;
			report_info("Array [" + variableExtention.getVarName() + "] declared", variableExtention);
		} else {
			report_info("Variable [" + variableExtention.getVarName() + "] declared", variableExtention);
			if (universeScope)
				this.numGlobalVars++;
		}
		
		Tab.insert(Obj.Var, variableExtention.getVarName(), veType);
		
	}
	
	public void visit(Constant c)
	{
		// if variable exists then output error
		if (Tab.currentScope.findSymbol(c.getVarName()) != null) {
			report_error("Error on line " + c.getLine() + ": name " + c.getVarName() + " already declared!", null);
			return;
		}
		
		Obj objC;
		if (c.getConst() instanceof NumConst)
		{
			NumConst numConst = (NumConst)c.getConst();
			int constVal = numConst.getNumConst().intValue();
			
			Struct intType = Tab.find("int").getType();
			
			if(c.getType().struct.equals(intType)) {
				objC = Tab.insert(Obj.Con, c.getVarName(), intType);
				objC.setAdr(constVal);
				this.numGlobalConstants++;
				report_info("Constant [" + c.getVarName() + "] declared", c);
			}
			else {
				report_error("Error on line " + c.getLine() + ": incompatible types! ", null);
			}
		} else if (c.getConst() instanceof CharConst)
		{
			CharConst charConst = (CharConst)c.getConst();
			int constVal = charConst.getCharConst().charAt(1);
			
			Struct charType = Tab.find("char").getType();
			
			if (c.getType().struct.equals(charType)) {
				objC = Tab.insert(Obj.Con, c.getVarName(), charType);
				objC.setAdr(constVal);
				this.numGlobalConstants++;
				report_info("Constant [" + c.getVarName() + "] declared", c);
			}
			else {
				report_error("Error on line " + c.getLine() + ": incompatible types! ", null);
			}
		} else if (c.getConst() instanceof BoolConst)
		{
			BoolConst boolConst = (BoolConst) c.getConst();
			int constVal = boolConst.getBoolConst().equals("true") ? 1 : 0;
			
			Struct boolType = Tab.find("bool").getType();
			if (c.getType().struct.equals(boolType))
			{
				objC = Tab.insert(Obj.Con, c.getVarName(), boolType);
				objC.setAdr(constVal);
				this.numGlobalConstants++;
				report_info("Constant [" + c.getVarName() + "] declared", c);
			}else {
				report_error("Error on line " + c.getLine() + ": incompatible types! ", null);
			}
		}
	}
	
	public void visit(ConstantExtention c)
	{
		// if variable exists then output error
		if (Tab.currentScope.findSymbol(c.getVarName()) != null) {
			report_error("Error on line " + c.getLine() + ": name " + c.getVarName() + " already declared!", null);
			return;
		}
		
		// find the type of the constant
		SyntaxNode parent = c.getParent();
		while (!(parent instanceof Constant))
			parent = parent.getParent();
		Constant cParent = (Constant)parent;
		
		Struct cType = cParent.getType().struct;
		
		Obj objC;
		if (c.getConst() instanceof NumConst)
		{
			NumConst numConst = (NumConst)c.getConst();
			int constVal = numConst.getNumConst().intValue();
			
			Struct intType = Tab.find("int").getType();
			
			if(cType.equals(intType)) {
				objC = Tab.insert(Obj.Con, c.getVarName(), intType);
				objC.setAdr(constVal);
				this.numGlobalConstants++;
				report_info("Constant [" + c.getVarName() + "] declared", c);
			}
			else {
				report_error("Error on line " + c.getLine() + ": incompatible types! ", null);
			}
		} else if (c.getConst() instanceof CharConst)
		{
			CharConst charConst = (CharConst)c.getConst();
			int constVal = charConst.getCharConst().charAt(1);
			
			Struct charType = Tab.find("char").getType();
			
			if (cType.equals(charType)) {
				objC = Tab.insert(Obj.Con, c.getVarName(), charType);
				objC.setAdr(constVal);
				this.numGlobalConstants++;
				report_info("Constant [" + c.getVarName() + "] declared", c);
			}
			else {
				report_error("Error on line " + c.getLine() + ": incompatible types! ", null);	
			}
		} else if (c.getConst() instanceof BoolConst)
		{
			BoolConst boolConst = (BoolConst) c.getConst();
			int constVal = boolConst.getBoolConst().equals("true") ? 1 : 0;
			
			Struct boolType = Tab.find("bool").getType();
			if (cType.equals(boolType))
			{
				objC = Tab.insert(Obj.Con, c.getVarName(), boolType);
				objC.setAdr(constVal);
				this.numGlobalConstants++;
				report_info("Constant [" + c.getVarName() + "] declared", c);
			}else {
				report_error("Error on line " + c.getLine() + ": incompatible types! ", null);
			}
		}
	}
	
	public void visit(Type type)
	{
		Obj typeNode = Tab.find(type.getTypeName());
		if (typeNode == Tab.noObj)
		{
			report_error("Type not found " + type.getTypeName() + " in symbol table! ", null);
			type.struct = Tab.noType;
		} else
		{
			if (Obj.Type == typeNode.getKind())
				type.struct = typeNode.getType();
			else {
				report_error("Error: Name " + type.getTypeName() + " isn't a type!" , type);
				type.struct = Tab.noType;
			}
		}
	}
	
	public void visit(MethodTypeName methodTypeName)
	{
		currentMethod = Tab.insert(Obj.Meth, methodTypeName.getMethodName(), Tab.noType);
		methodTypeName.obj = currentMethod;
		Tab.openScope();
		this.universeScope = false;
		report_info("Handling method " + methodTypeName.getMethodName(), methodTypeName);
	}
	
	public void visit(Method method)
	{
		Tab.chainLocalSymbols(currentMethod);
		this.numMainVars = currentMethod.getLocalSymbols().size();
		Tab.closeScope();
		currentMethod = null;
	}
	
	public void visit(DesignatorStatement stmt) { this.numMainStatements++; }
	
	public void visit(ReadStatement stmt) 
	{ 
		this.numMainStatements++; 
		Designator d = stmt.getDesignator();
		Struct dType = d.obj.getType();
		if (d.obj.getKind() != Obj.Var)
			report_error("Error on line " + d.getLine() + ": " + d.getDesignatorName().getVarName() + " must be a variable!", null);
		else if (dType.getKind() == Struct.Array) {
			if (!(d.getDesignatorExtention() instanceof ArrayField))
				report_error("Error on line " + d.getLine() + ": " + d.getDesignatorName().getVarName() + " is an array, and read statement accepts only array elements!", null);
		}
			
	}
	public void visit(PrintStatement stmt) 
	{ 
		this.numMainStatements++;
		Expr e = stmt.getExpr();
		if (!e.struct.equals(Tab.intType) && !e.struct.equals(Tab.charType) && !e.struct.equals(Tab.find("bool").getType()))
			report_error("Error on line " + stmt.getLine() + ": print statement accepts only int, char, bool type!", null);
	}
	
	public void visit(AssignOperation aop)
	{
		DesignatorStatement s = (DesignatorStatement) aop.getParent();
		Designator d = s.getDesignator();
		
		if (d.obj.getKind() != Obj.Var)
			report_error("Error on line " + d.getLine() + ": a variable must be on the left side of assignment!", null);
		else if (d.obj.getType().getKind() == Struct.Array) {
			if (aop.getExpr().struct == Tab.nullType) 
				return;
			if (!aop.getExpr().struct.assignableTo(d.obj.getType().getElemType()))
				report_error("Error on line " + d.getLine() + ": expression isn't assignable to the designator!", null);
		}
		else if (!aop.getExpr().struct.assignableTo(d.obj.getType()))
			report_error("Error on line " + d.getLine() + ": expression isn't assignable to the designator!", null);
	}
	
	public void visit(Expression e)
	{
		e.struct = e.getExpr1().struct;
	}
	
	public void visit(CondFactExpression cfe) 
	{
		Condition condition = cfe.getCondition();
		FirstExpr first = cfe.getFirstExpr();
		SecondExpr second = cfe.getSecondExpr();
		
		if (!condition.struct.equals(Tab.find("bool").getType())) {
			cfe.struct = Tab.noType;
			report_error("Error on line " + first.getLine() + ": condition must be bool type!", null);
		}
		else if (!first.struct.equals(second.struct)) {
			cfe.struct = Tab.noType;
			report_error("Error on line " + first.getLine() + ": expr1 and expr2 must be same types!", null);
		}
		else 
			cfe.struct = first.struct;
	}
	
	public void visit(Condition con) { con.struct = con.getExpr1().struct; }
	public void visit(FirstExpr first) { first.struct = first.getExpr1().struct; }
	public void visit(SecondExpr second) { second.struct = second.getExpr1().struct; }
	
	public void visit(AddopExpression exp)
	{
		Expr1 expChild = exp.getExpr1();
		Term termChild = exp.getTerm();
		
		if (expChild.struct.equals(termChild.struct) && expChild.struct.equals(Tab.intType))
			exp.struct = expChild.struct;
		else {
			exp.struct = Tab.noType;
			report_error("Error on line " + exp.getLine() + ": trying to addop invalid type!", null);
		}
	}
	
	public void visit(TermExpression termExp)
	{
		MinusOpt minus = termExp.getMinusOpt();
		Term termChild = termExp.getTerm();
		
		if (minus instanceof MinusSign) {
			if (!termChild.struct.equals(Tab.intType)) {
				termExp.struct = Tab.noType;
				report_error("Error on line " + termExp.getLine() + ": minus sign must be in front of int type!", null);
			}
			else
				termExp.struct = termChild.struct;
		}
		else
			termExp.struct = termChild.struct;
		
	}
	
	public void visit(MulopTerm t)
	{
		Factor factorChild = t.getFactor();
		Term termChild = t.getTerm();
		
		if (factorChild.struct.equals(termChild.struct) && factorChild.struct.equals(Tab.intType))
			t.struct = factorChild.struct;
		else {
			report_error("Error on line " + t.getLine() + ": trying to mulop invalid type!", null);
			t.struct = Tab.noType;
		}
			
	}
	
	public void visit(FactorTerm term)
	{
		term.struct = term.getFactor().struct;
	}
	
	public void visit(Designator d)
	{
		Obj obj = Tab.find(d.getDesignatorName().getVarName());
		if (obj == Tab.noObj) {
			d.obj = Tab.noObj;
			report_error("Error on line " + d.getLine() + ": name " + d.getDesignatorName().getVarName() + " not declared!", null);
		}
		else {
			d.obj = obj;
			CustomDumpSymbolTableVisitor visitor =  new CustomDumpSymbolTableVisitor();
			d.obj.accept(visitor);
			report_info("Searching on line " + d.getLine() + ": Found " + d.getDesignatorName().getVarName() + ": " + visitor.getOutput(), null);
		}
		
	}
	
	public void visit(ArrayField af)
	{
		Designator d = (Designator)af.getParent();
		
		Obj obj = Tab.find(d.getDesignatorName().getVarName());
		if (obj == Tab.noObj)
		{
			report_error("Error on line " + d.getLine() + ": name " + d.getDesignatorName().getVarName() + " not declared!", null);
		} 
		d.obj = obj;
		
		if (d.obj.getType().getKind() != Struct.Array)
			report_error("Error on line " + d.getLine() + ": cannot access a field of a non array variable!", null);
		else if (!af.getExpr().struct.equals(Tab.intType))
			report_error("Error on line " + d.getLine() + ": array accesser must be int type!", null);
	}
	
	public void visit(Increment i)
	{
		DesignatorStatement s = (DesignatorStatement)i.getParent();
		Designator d = s.getDesignator();
		if (Tab.find(d.getDesignatorName().getVarName()) != Tab.noObj)
		{
			Struct dType = d.obj.getType();
			if (dType.getKind() == Struct.Array) {
				DesignatorExtention de = (DesignatorExtention)d.getDesignatorExtention();
				if (!(de instanceof ArrayField))
					report_error("Error on line "+d.getLine()+": arrays can't be incremented, only their elements!", null);
				else if (!dType.getElemType().equals(Tab.intType))
					report_error("Error on line "+d.getLine()+": increment variable element must be int type!", null);
			}
			else if (!dType.equals(Tab.intType)) {	
					report_error("Error on line "+d.getLine()+": increment variable must be int type!", null);
			}
			else if (d.obj.getKind() != Obj.Var) 
				report_error("Error on line "+d.getLine()+": increment designator must be a variable!", null);
		} 
	}			
	
	public void visit(Decrement dec)
	{
		DesignatorStatement s = (DesignatorStatement)dec.getParent();
		Designator d = s.getDesignator();
		if (Tab.find(d.getDesignatorName().getVarName()) != Tab.noObj)
		{
			Struct dType = d.obj.getType();
			if (dType.getKind() == Struct.Array) {
				DesignatorExtention de = (DesignatorExtention)d.getDesignatorExtention();
				if (!(de instanceof ArrayField))
					report_error("Error on line "+d.getLine()+": arrays can't be incremented, only their elements!", null);
				else if (!dType.getElemType().equals(Tab.intType))
					report_error("Error on line "+d.getLine()+": decrement variable element must be int type!", null);
			}
			else if (!dType.equals(Tab.intType)) {	
					report_error("Error on line "+d.getLine()+": decrement variable must be int type!", null);
			}
			else if (d.obj.getKind() != Obj.Var) 
				report_error("Error on line "+d.getLine()+": decrement designator must be a variable!", null);
		}
	}
	
	public void visit(AllocFactor af)
	{
		Expr e = af.getExpr();
		if (!e.struct.equals(Tab.intType)) {
			report_error("Error on line " + af.getLine() + ": size to allocate must be type int!", null);
			af.struct = Tab.intType;
		}
		else
			af.struct = Tab.nullType;
		
	}
	
	public void visit(ConstFactor cf)
	{
		Const c = cf.getConst();
		if (c instanceof NumConst)
			cf.struct = Tab.intType;
		else if (c instanceof CharConst)
			cf.struct = Tab.charType;
		else if (c instanceof BoolConst)
			cf.struct = Tab.find("bool").getType();
	}
	
	public void visit(DesigFactor df)
	{
		Designator d = df.getDesignator();
		
		if (d.obj.getType().getKind() == Struct.Array)
		{
			if (d.getDesignatorExtention() instanceof ArrayField)
				df.struct = d.obj.getType().getElemType();
			else
				df.struct = d.obj.getType();
		} else 
			df.struct = d.obj.getType();
	}
	
	public void visit(ExprFactor ef)
	{
		ef.struct = ef.getExpr().struct;
	}
	
	public boolean passed()
	{
		return this.numOfErrors == 0;
	}
	
	public String finalReport()
	{
		StringBuilder report = new StringBuilder();
																		
		report.append("==================== Syntax Analyzer : Final Report ===============================\n");
		report.append("Methods in the program: 1 \n");
		report.append("Global variables: " + this.numGlobalVars + "\n");
		report.append("Global constants: " + this.numGlobalConstants + "\n");
		report.append("Global arrays: " + this.numGlobalArrays + "\n");
		report.append("Local variables/arrays in main: " + this.numMainVars + "\n");
		report.append("Statements in main: " + this.numMainStatements + "\n");
		report.append("Finished with " + this.numOfErrors + " error(s)");
		return report.toString();
	}
	
	public String report() { return this.report.toString(); }
}































