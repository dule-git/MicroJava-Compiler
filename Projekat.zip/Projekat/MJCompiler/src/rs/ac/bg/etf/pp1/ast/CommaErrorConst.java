// generated with ast extension for cup
// version 0.8
// 12/0/2021 21:11:35


package rs.ac.bg.etf.pp1.ast;

public class CommaErrorConst extends ConstDecl {

    private ConstDeclRecovery ConstDeclRecovery;

    public CommaErrorConst (ConstDeclRecovery ConstDeclRecovery) {
        this.ConstDeclRecovery=ConstDeclRecovery;
        if(ConstDeclRecovery!=null) ConstDeclRecovery.setParent(this);
    }

    public ConstDeclRecovery getConstDeclRecovery() {
        return ConstDeclRecovery;
    }

    public void setConstDeclRecovery(ConstDeclRecovery ConstDeclRecovery) {
        this.ConstDeclRecovery=ConstDeclRecovery;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConstDeclRecovery!=null) ConstDeclRecovery.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConstDeclRecovery!=null) ConstDeclRecovery.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConstDeclRecovery!=null) ConstDeclRecovery.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("CommaErrorConst(\n");

        if(ConstDeclRecovery!=null)
            buffer.append(ConstDeclRecovery.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [CommaErrorConst]");
        return buffer.toString();
    }
}
