// generated with ast extension for cup
// version 0.8
// 12/0/2021 21:11:35


package rs.ac.bg.etf.pp1.ast;

public class CommaErrorVar extends VarDecl {

    private VarDeclRecovery VarDeclRecovery;

    public CommaErrorVar (VarDeclRecovery VarDeclRecovery) {
        this.VarDeclRecovery=VarDeclRecovery;
        if(VarDeclRecovery!=null) VarDeclRecovery.setParent(this);
    }

    public VarDeclRecovery getVarDeclRecovery() {
        return VarDeclRecovery;
    }

    public void setVarDeclRecovery(VarDeclRecovery VarDeclRecovery) {
        this.VarDeclRecovery=VarDeclRecovery;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(VarDeclRecovery!=null) VarDeclRecovery.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(VarDeclRecovery!=null) VarDeclRecovery.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(VarDeclRecovery!=null) VarDeclRecovery.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("CommaErrorVar(\n");

        if(VarDeclRecovery!=null)
            buffer.append(VarDeclRecovery.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [CommaErrorVar]");
        return buffer.toString();
    }
}
