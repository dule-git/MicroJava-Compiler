// generated with ast extension for cup
// version 0.8
// 12/0/2021 21:11:35


package rs.ac.bg.etf.pp1.ast;

public class ConstantExtention extends ConstDeclExtention {

    private String varName;
    private Const Const;
    private ConstDeclExtention ConstDeclExtention;

    public ConstantExtention (String varName, Const Const, ConstDeclExtention ConstDeclExtention) {
        this.varName=varName;
        this.Const=Const;
        if(Const!=null) Const.setParent(this);
        this.ConstDeclExtention=ConstDeclExtention;
        if(ConstDeclExtention!=null) ConstDeclExtention.setParent(this);
    }

    public String getVarName() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName=varName;
    }

    public Const getConst() {
        return Const;
    }

    public void setConst(Const Const) {
        this.Const=Const;
    }

    public ConstDeclExtention getConstDeclExtention() {
        return ConstDeclExtention;
    }

    public void setConstDeclExtention(ConstDeclExtention ConstDeclExtention) {
        this.ConstDeclExtention=ConstDeclExtention;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Const!=null) Const.accept(visitor);
        if(ConstDeclExtention!=null) ConstDeclExtention.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Const!=null) Const.traverseTopDown(visitor);
        if(ConstDeclExtention!=null) ConstDeclExtention.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Const!=null) Const.traverseBottomUp(visitor);
        if(ConstDeclExtention!=null) ConstDeclExtention.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ConstantExtention(\n");

        buffer.append(" "+tab+varName);
        buffer.append("\n");

        if(Const!=null)
            buffer.append(Const.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(ConstDeclExtention!=null)
            buffer.append(ConstDeclExtention.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ConstantExtention]");
        return buffer.toString();
    }
}
