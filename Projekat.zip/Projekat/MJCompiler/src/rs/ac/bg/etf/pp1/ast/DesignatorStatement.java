// generated with ast extension for cup
// version 0.8
// 12/0/2021 21:11:35


package rs.ac.bg.etf.pp1.ast;

public class DesignatorStatement extends Statement {

    private Designator Designator;
    private DesignatorStatementExtention DesignatorStatementExtention;

    public DesignatorStatement (Designator Designator, DesignatorStatementExtention DesignatorStatementExtention) {
        this.Designator=Designator;
        if(Designator!=null) Designator.setParent(this);
        this.DesignatorStatementExtention=DesignatorStatementExtention;
        if(DesignatorStatementExtention!=null) DesignatorStatementExtention.setParent(this);
    }

    public Designator getDesignator() {
        return Designator;
    }

    public void setDesignator(Designator Designator) {
        this.Designator=Designator;
    }

    public DesignatorStatementExtention getDesignatorStatementExtention() {
        return DesignatorStatementExtention;
    }

    public void setDesignatorStatementExtention(DesignatorStatementExtention DesignatorStatementExtention) {
        this.DesignatorStatementExtention=DesignatorStatementExtention;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Designator!=null) Designator.accept(visitor);
        if(DesignatorStatementExtention!=null) DesignatorStatementExtention.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Designator!=null) Designator.traverseTopDown(visitor);
        if(DesignatorStatementExtention!=null) DesignatorStatementExtention.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Designator!=null) Designator.traverseBottomUp(visitor);
        if(DesignatorStatementExtention!=null) DesignatorStatementExtention.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("DesignatorStatement(\n");

        if(Designator!=null)
            buffer.append(Designator.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(DesignatorStatementExtention!=null)
            buffer.append(DesignatorStatementExtention.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [DesignatorStatement]");
        return buffer.toString();
    }
}
