// generated with ast extension for cup
// version 0.8
// 12/0/2021 21:11:35


package rs.ac.bg.etf.pp1.ast;

public class VariableExtention extends VarDeclExtention {

    private String varName;
    private Brackets Brackets;
    private VarDeclExtention VarDeclExtention;

    public VariableExtention (String varName, Brackets Brackets, VarDeclExtention VarDeclExtention) {
        this.varName=varName;
        this.Brackets=Brackets;
        if(Brackets!=null) Brackets.setParent(this);
        this.VarDeclExtention=VarDeclExtention;
        if(VarDeclExtention!=null) VarDeclExtention.setParent(this);
    }

    public String getVarName() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName=varName;
    }

    public Brackets getBrackets() {
        return Brackets;
    }

    public void setBrackets(Brackets Brackets) {
        this.Brackets=Brackets;
    }

    public VarDeclExtention getVarDeclExtention() {
        return VarDeclExtention;
    }

    public void setVarDeclExtention(VarDeclExtention VarDeclExtention) {
        this.VarDeclExtention=VarDeclExtention;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(Brackets!=null) Brackets.accept(visitor);
        if(VarDeclExtention!=null) VarDeclExtention.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(Brackets!=null) Brackets.traverseTopDown(visitor);
        if(VarDeclExtention!=null) VarDeclExtention.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(Brackets!=null) Brackets.traverseBottomUp(visitor);
        if(VarDeclExtention!=null) VarDeclExtention.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("VariableExtention(\n");

        buffer.append(" "+tab+varName);
        buffer.append("\n");

        if(Brackets!=null)
            buffer.append(Brackets.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        if(VarDeclExtention!=null)
            buffer.append(VarDeclExtention.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [VariableExtention]");
        return buffer.toString();
    }
}
