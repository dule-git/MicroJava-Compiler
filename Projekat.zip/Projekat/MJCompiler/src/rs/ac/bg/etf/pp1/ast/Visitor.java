// generated with ast extension for cup
// version 0.8
// 12/0/2021 21:11:35


package rs.ac.bg.etf.pp1.ast;

public interface Visitor { 

    public void visit(DesignatorStatementExtention DesignatorStatementExtention);
    public void visit(VarDeclExtention VarDeclExtention);
    public void visit(Mulop Mulop);
    public void visit(MethodDecl MethodDecl);
    public void visit(DesignatorExtention DesignatorExtention);
    public void visit(Relop Relop);
    public void visit(Assignop Assignop);
    public void visit(StatementList StatementList);
    public void visit(Addop Addop);
    public void visit(NumConstOpt NumConstOpt);
    public void visit(MinusOpt MinusOpt);
    public void visit(Factor Factor);
    public void visit(ConstDeclExtention ConstDeclExtention);
    public void visit(Term Term);
    public void visit(Brackets Brackets);
    public void visit(VarDeclList VarDeclList);
    public void visit(Expr Expr);
    public void visit(Expr1 Expr1);
    public void visit(Const Const);
    public void visit(Statement Statement);
    public void visit(VarDecl VarDecl);
    public void visit(ConstDecl ConstDecl);
    public void visit(Declaration Declaration);
    public void visit(MethodDeclList MethodDeclList);
    public void visit(NoNumberConst NoNumberConst);
    public void visit(NumberConst NumberConst);
    public void visit(PlusSign PlusSign);
    public void visit(MinusSign MinusSign);
    public void visit(Mod Mod);
    public void visit(DividedBy DividedBy);
    public void visit(Times Times);
    public void visit(Minus Minus);
    public void visit(Plus Plus);
    public void visit(Assign Assign);
    public void visit(NoBrackets NoBrackets);
    public void visit(YesBrackets YesBrackets);
    public void visit(Type Type);
    public void visit(BoolConst BoolConst);
    public void visit(CharConst CharConst);
    public void visit(NumConst NumConst);
    public void visit(ConstDeclRecovery ConstDeclRecovery);
    public void visit(NoConstantExtention NoConstantExtention);
    public void visit(CommaErrorConstExt CommaErrorConstExt);
    public void visit(SemiErrorConstExt SemiErrorConstExt);
    public void visit(ConstantExtention ConstantExtention);
    public void visit(CommaErrorConst CommaErrorConst);
    public void visit(SemiErrorConst SemiErrorConst);
    public void visit(Constant Constant);
    public void visit(VarDeclRecovery VarDeclRecovery);
    public void visit(NoVariableExtention NoVariableExtention);
    public void visit(CommaErrorVarExt CommaErrorVarExt);
    public void visit(SemiErrorVarExt SemiErrorVarExt);
    public void visit(VariableExtention VariableExtention);
    public void visit(CommaErrorVar CommaErrorVar);
    public void visit(SemiErrorVar SemiErrorVar);
    public void visit(Variable Variable);
    public void visit(NoVariableDeclarationList NoVariableDeclarationList);
    public void visit(VariableDeclarationList VariableDeclarationList);
    public void visit(ExprFactor ExprFactor);
    public void visit(AllocFactor AllocFactor);
    public void visit(ConstFactor ConstFactor);
    public void visit(DesigFactor DesigFactor);
    public void visit(FactorTerm FactorTerm);
    public void visit(MulopTerm MulopTerm);
    public void visit(TermExpression TermExpression);
    public void visit(AddopExpression AddopExpression);
    public void visit(SecondExpr SecondExpr);
    public void visit(FirstExpr FirstExpr);
    public void visit(Condition Condition);
    public void visit(CondFactExpression CondFactExpression);
    public void visit(Expression Expression);
    public void visit(Decrement Decrement);
    public void visit(Increment Increment);
    public void visit(AssignOperation AssignOperation);
    public void visit(NoArrayField NoArrayField);
    public void visit(ArrayField ArrayField);
    public void visit(DesignatorName DesignatorName);
    public void visit(Designator Designator);
    public void visit(SemiErrorStatement SemiErrorStatement);
    public void visit(PrintStatement PrintStatement);
    public void visit(ReadStatement ReadStatement);
    public void visit(DesignatorStatement DesignatorStatement);
    public void visit(NoStatementListItem NoStatementListItem);
    public void visit(StatementListItem StatementListItem);
    public void visit(MethodTypeName MethodTypeName);
    public void visit(Method Method);
    public void visit(NoMethodDeclaration NoMethodDeclaration);
    public void visit(MethodDeclaration MethodDeclaration);
    public void visit(NoDeclaration NoDeclaration);
    public void visit(ConstDeclaration ConstDeclaration);
    public void visit(VarDeclaration VarDeclaration);
    public void visit(ProgramName ProgramName);
    public void visit(Program Program);

}
