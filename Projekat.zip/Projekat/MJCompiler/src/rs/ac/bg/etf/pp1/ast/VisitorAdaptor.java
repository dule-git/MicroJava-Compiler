// generated with ast extension for cup
// version 0.8
// 12/0/2021 21:11:35


package rs.ac.bg.etf.pp1.ast;

public abstract class VisitorAdaptor implements Visitor { 

    public void visit(DesignatorStatementExtention DesignatorStatementExtention) { }
    public void visit(VarDeclExtention VarDeclExtention) { }
    public void visit(Mulop Mulop) { }
    public void visit(MethodDecl MethodDecl) { }
    public void visit(DesignatorExtention DesignatorExtention) { }
    public void visit(Relop Relop) { }
    public void visit(Assignop Assignop) { }
    public void visit(StatementList StatementList) { }
    public void visit(Addop Addop) { }
    public void visit(NumConstOpt NumConstOpt) { }
    public void visit(MinusOpt MinusOpt) { }
    public void visit(Factor Factor) { }
    public void visit(ConstDeclExtention ConstDeclExtention) { }
    public void visit(Term Term) { }
    public void visit(Brackets Brackets) { }
    public void visit(VarDeclList VarDeclList) { }
    public void visit(Expr Expr) { }
    public void visit(Expr1 Expr1) { }
    public void visit(Const Const) { }
    public void visit(Statement Statement) { }
    public void visit(VarDecl VarDecl) { }
    public void visit(ConstDecl ConstDecl) { }
    public void visit(Declaration Declaration) { }
    public void visit(MethodDeclList MethodDeclList) { }
    public void visit(NoNumberConst NoNumberConst) { visit(); }
    public void visit(NumberConst NumberConst) { visit(); }
    public void visit(PlusSign PlusSign) { visit(); }
    public void visit(MinusSign MinusSign) { visit(); }
    public void visit(Mod Mod) { visit(); }
    public void visit(DividedBy DividedBy) { visit(); }
    public void visit(Times Times) { visit(); }
    public void visit(Minus Minus) { visit(); }
    public void visit(Plus Plus) { visit(); }
    public void visit(Assign Assign) { visit(); }
    public void visit(NoBrackets NoBrackets) { visit(); }
    public void visit(YesBrackets YesBrackets) { visit(); }
    public void visit(Type Type) { visit(); }
    public void visit(BoolConst BoolConst) { visit(); }
    public void visit(CharConst CharConst) { visit(); }
    public void visit(NumConst NumConst) { visit(); }
    public void visit(ConstDeclRecovery ConstDeclRecovery) { visit(); }
    public void visit(NoConstantExtention NoConstantExtention) { visit(); }
    public void visit(CommaErrorConstExt CommaErrorConstExt) { visit(); }
    public void visit(SemiErrorConstExt SemiErrorConstExt) { visit(); }
    public void visit(ConstantExtention ConstantExtention) { visit(); }
    public void visit(CommaErrorConst CommaErrorConst) { visit(); }
    public void visit(SemiErrorConst SemiErrorConst) { visit(); }
    public void visit(Constant Constant) { visit(); }
    public void visit(VarDeclRecovery VarDeclRecovery) { visit(); }
    public void visit(NoVariableExtention NoVariableExtention) { visit(); }
    public void visit(CommaErrorVarExt CommaErrorVarExt) { visit(); }
    public void visit(SemiErrorVarExt SemiErrorVarExt) { visit(); }
    public void visit(VariableExtention VariableExtention) { visit(); }
    public void visit(CommaErrorVar CommaErrorVar) { visit(); }
    public void visit(SemiErrorVar SemiErrorVar) { visit(); }
    public void visit(Variable Variable) { visit(); }
    public void visit(NoVariableDeclarationList NoVariableDeclarationList) { visit(); }
    public void visit(VariableDeclarationList VariableDeclarationList) { visit(); }
    public void visit(ExprFactor ExprFactor) { visit(); }
    public void visit(AllocFactor AllocFactor) { visit(); }
    public void visit(ConstFactor ConstFactor) { visit(); }
    public void visit(DesigFactor DesigFactor) { visit(); }
    public void visit(FactorTerm FactorTerm) { visit(); }
    public void visit(MulopTerm MulopTerm) { visit(); }
    public void visit(TermExpression TermExpression) { visit(); }
    public void visit(AddopExpression AddopExpression) { visit(); }
    public void visit(SecondExpr SecondExpr) { visit(); }
    public void visit(FirstExpr FirstExpr) { visit(); }
    public void visit(Condition Condition) { visit(); }
    public void visit(CondFactExpression CondFactExpression) { visit(); }
    public void visit(Expression Expression) { visit(); }
    public void visit(Decrement Decrement) { visit(); }
    public void visit(Increment Increment) { visit(); }
    public void visit(AssignOperation AssignOperation) { visit(); }
    public void visit(NoArrayField NoArrayField) { visit(); }
    public void visit(ArrayField ArrayField) { visit(); }
    public void visit(DesignatorName DesignatorName) { visit(); }
    public void visit(Designator Designator) { visit(); }
    public void visit(SemiErrorStatement SemiErrorStatement) { visit(); }
    public void visit(PrintStatement PrintStatement) { visit(); }
    public void visit(ReadStatement ReadStatement) { visit(); }
    public void visit(DesignatorStatement DesignatorStatement) { visit(); }
    public void visit(NoStatementListItem NoStatementListItem) { visit(); }
    public void visit(StatementListItem StatementListItem) { visit(); }
    public void visit(MethodTypeName MethodTypeName) { visit(); }
    public void visit(Method Method) { visit(); }
    public void visit(NoMethodDeclaration NoMethodDeclaration) { visit(); }
    public void visit(MethodDeclaration MethodDeclaration) { visit(); }
    public void visit(NoDeclaration NoDeclaration) { visit(); }
    public void visit(ConstDeclaration ConstDeclaration) { visit(); }
    public void visit(VarDeclaration VarDeclaration) { visit(); }
    public void visit(ProgramName ProgramName) { visit(); }
    public void visit(Program Program) { visit(); }


    public void visit() { }
}
